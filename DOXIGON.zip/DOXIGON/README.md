#How to run
First run LibraryInstaller  in order for the programs to work, then open cmd prompt and type
each line of requirements.txt into CMD prompt. Then enjoy!

- The Doxigon Team


#About

TYSM FOR NEW USERS! FREE PROXYS!

This is a expiremental python and batch project for fun, testing IP addresses and what hackers can do with them.
Please use responsibly as their are consequences to your actions, do not use for malicous
purposes and use for educational purposes. We are ethical hackers! :DThe point of this project is to see how much you can do with just a IP adress.
Don't trust us? These files are opened sourced and code can be viewd non obfuscated by simply right clicking. :)
FEATURES
- Ddos
- Doxxer
- Port Scanner
- Pinger