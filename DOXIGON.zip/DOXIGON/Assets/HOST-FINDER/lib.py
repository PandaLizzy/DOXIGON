import nmap

class Network(object):
    def __init__(self):
        ip = input("Gimme ur IP:")
        self.ip = ip

    def networkscanner(self):
        if len(self.ip) == 0:
            network = '192.168.1.1/24'
        else:
            network = self.ip + '/24'
        
    print("Scanning pls wait lol")

    nm = nmap.PortScanner()
    nm.scan(host=network, arguments='-sn')
    host_list = [(x, nm[x]['status']['state']) for x in nm.all_host()]
    for host, status in host_list:
        print("Host\t{}".format(host))
if __name__ == "__main__":
    D = Network()
    D.networkscanner()